import React from "react";
import './App.css';
import BoxGenerator from './components/BoxGenerator';
import Display from "./components/Display";

function App() {
  return (
    <div className="App">
      <BoxGenerator/>
      {/* <Display/> */}
    </div>
  );
}

export default App;
